/**
 * 
 */
/**
 * 
 */
module game_of_life {
	requires java.desktop;
}