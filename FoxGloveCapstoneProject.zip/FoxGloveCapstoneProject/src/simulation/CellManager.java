package simulation;

/*UMGC CAPSTONE PROJECT
* Title:Game of Life in Java By Team Fox Glove:
*         Anthony Farias
          Mitchell Howard
          Patrick Kamdem
          Hyrum Madson
          Bensaiten Sanchez Flores 
          
*CMSC 495 7380
*Professor Sanford
*February 12, 2024 
*
* CellManager class: it iterates over a set of cells during each pass. 
* If we add multithreading, each CellManager would get its own thread and some number of rows to manage. 
*/



import data.Neighbors;

/*
 * CellManager class: it iterates over a set of cells during each pass. 
 * If we add multithreading, each CellManager would get its own thread and some number of rows to manage. 
 */
public class CellManager {
	private int rowOffset;
	private int rowCount;
	
	public void calculateFrame() {
		
	}
	
	public void updateGUI() {
		
	}
}
